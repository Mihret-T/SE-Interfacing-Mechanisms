﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PubSub
{
    class Program
    {
        static void Main(string[] args)
        {
            //inistantiate publishers
            Publisher africaNewsPublisher = new Publisher();
            Publisher worldNewsPublisher = new Publisher();

            // inistantiate subscribers 
            Subscriber africaNewsSubscriber = new Subscriber();
            Subscriber worldNewsSubscriber = new Subscriber();
            Subscriber allNewsSubscriber = new Subscriber();


            //and  inistantiate PubSubService
            PubSubService Service = new PubSubService();

            //Declare Message 
            Message africaNews1 = new Message();
            africaNews1.topics = "Africa";
            africaNews1.payload = "News related to Afica only";

            Message worldNews1 = new Message();
            worldNews1.topics = "World";
            worldNews1.payload = "International News";

            //Publish Message to PubSubService
            africaNewsPublisher.Send(africaNews1, Service);
           worldNewsPublisher.Send(worldNews1, Service);

            //declare subscribers
            africaNewsSubscriber.Listen("Africa", 0);   // Java subscriber only subscribes to Java topics
            worldNewsSubscriber.Listen("World", 1);   //Python subscriber only subscribes to Python topics

            //all subscriber, subscribes to both Java and Python
            allNewsSubscriber.Listen("Africa", 0);
            allNewsSubscriber.Listen("World", 1);


            Service.subscribers[0] = africaNewsSubscriber;
            Service.subscribers[1] = worldNewsSubscriber;
            Service.subscribers[2] = allNewsSubscriber;
           

            Service.Forward();

            Console.WriteLine("Messages of african News Subscrbers are: ");
            africaNewsSubscriber.print();

            Console.WriteLine("");

            Console.WriteLine("Messages of world News Subscriber are: ");
           worldNewsSubscriber.print();

            Console.WriteLine(" ");

            Console.WriteLine("Messages of ALL News Subscribers are ");
            allNewsSubscriber.print();

            Console.Read();


        }
    }
}
