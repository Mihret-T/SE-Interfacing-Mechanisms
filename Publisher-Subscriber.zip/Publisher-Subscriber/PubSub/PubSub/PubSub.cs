﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PubSub
{
    class Publisher
    {
        public Publisher()
        {

        }
        public void Send(Message newMessage, PubSubService myService)
        {
            //enqueue into the buffer
            myService.buffer.Enqueue(newMessage);
        }
    };

    class Subscriber
    {

        public Subscriber()
        {

        }
        //number of topics restricted to 2 topics
        public string[] topics = new string[2];

        public Queue<Message> myMessages = new Queue<Message>();
        public void Listen(string newTopic, int index) //tells the program that u wants to listen to certain topics
        {
            topics[index] = newTopic;
        }

        public void print()
        {
            for (int i = 0; i < topics.Length; i++)
            {
                while (myMessages.Count != 0)
                {
                    Message newMessage = myMessages.Dequeue();
                    Console.WriteLine("Topic: " + newMessage.topics + "\n" + newMessage.payload);
                }
            }
        }
    };

    class Message
    {
        public Message()
        {
        }
        public string payload; //the actual message
        public string topics;
    };

    class PubSubService
    {
        public PubSubService()
        {

        }
        //buffer of messages
        public Queue<Message> buffer = new Queue<Message>();
        //lists of subscribers
        public Subscriber[] subscribers = new Subscriber[3];
        public void Forward()
        {
            while (buffer.Count != 0) //check if the buffer is empty
            {
                Message tempMessage = buffer.Dequeue();
                for (int i = 0; i < subscribers.Length; i++)
                {
                    for (int j = 0; j < subscribers[i].topics.Length; j++)
                    {
                        if (tempMessage.topics == subscribers[i].topics[j])
                        {
                            subscribers[i].myMessages.Enqueue(tempMessage);
                        }

                    }

                }
            }

        }
    };

 
}
