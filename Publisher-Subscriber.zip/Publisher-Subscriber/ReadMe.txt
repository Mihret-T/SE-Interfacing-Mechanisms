Publisher Subscriber architecture

Publishers are the entities who create/publish a message on a topic. 
Subscribers are the entities who subscribe to messages on a topic.

In a topic based Publish-Subscribe pattern, Publishers tag each message with the topic instead of referencing specific Subscribers. Messaging system then sends the message to all Subscribers who have asked to receive messages on that topic.

Publishers only concern themselves with creating the original message and can leave the task of servicing the Subscribers to the messaging infrastructure.


	� It extends the communication infrastructure by including a topic for each message.
	� It enable listening applications to receive message from only specified topics
	� It creates a mechanism that sends message to all interested receivers


Actors in this program include:

	1. Publisher - It is the sender class that tags each message with the name of a topic.
	2. Subscriber - It is the receiver application that choose which topic to receive
	3. Pub-Sub Service - It is the director/middle man of all the messages and defines a 		uniform message structure.


In this program we limited the number of subscribers to 3 namely Africa News Subscribers, world News subscribers and all news Subscribers. We also have 2 publishers, Africa News publisher which publishes messages related to Africa only and similarly world publishers concerned international news only.

African news subscribers subscribes to Africa news only and world news subscribers only wants news concerned about the world as a whole. in contrast all news subscribers want both Africa and international news.

