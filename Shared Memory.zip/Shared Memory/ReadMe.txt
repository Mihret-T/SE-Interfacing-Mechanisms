﻿

Shared Memory is a type of Interprocess communication where two processes share the same memory segment.



Here we have 2 processed namely, server and client. The server process writes to the shared memory whereas the client process reads from the shared memory.



Server process
	
	> enter the text/message you want to save to the shared memory.
	
	> press ctrl + D when you are done entering
	
	> the processes waits until the entered text is read by the client process
	
	> exits when the text is read by the other process
	
	> detach from the shared segment before exiting
	
	> exit


Client process
	
	> this process reads the string stored in the shared memory one character at a time.
	
	> prints out the string read 
	
	> signals the server process that it had read what has been stored in the shared memory segment
	
	> detach and clears the the segment
	
	> exit

steps


1.run server.c

2.enter what you want to be read by the client.

3. press Ctrl + D to indicate you are done

4. the server process waits until the client reads the inserted string

5. run client.c

6. it displays what has been read from the shared memory

7. the server process detach from the segment and exits after the client finishes reading .

8.client process detach and exit. 

