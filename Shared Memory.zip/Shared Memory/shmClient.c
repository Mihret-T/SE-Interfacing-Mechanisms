//client.c

#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<stdio.h>
#include<stdlib.h>

#define SHMSIZE 100

int main(){
        int shm_id;
        key_t key;
        char *data, *shm;
        key = 1;
        /*get the segment created by the server*/
        
         shm_id =  shmget(key,SHMSIZE,IPC_CREAT | 0666);

        if(shm_id < 0){
                printf("shmget Error: Fail to create a memory segment\n");
                exit(1);
        }
        else{
              printf("Memory segment created successfully\n");
              printf("segment id id %d\n", shm_id);
        }
        data = shmat(shm_id, NULL, 0);
        
        if (data == (char *) -1){
                printf("shmat Error: Fail to attach\n");
                exit(1);
        }
        else{
                printf("Segement successfully attached to the client process\n");
        }
        
        /*read what the server put in the memory*/
        printf("Client reading data in the shared memory\n");
        for( shm = data;*shm != '\0'; shm++){
                putchar(*shm);
                putchar('\n');
               
        }
        *data = '*';
         shmdt(data);
        shmctl(shm_id, IPC_RMID, 0);
        exit(0);
        //clear the shared memory
}
