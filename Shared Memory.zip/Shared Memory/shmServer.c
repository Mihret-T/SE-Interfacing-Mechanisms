//server.c

#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h> 
  

#define SHMSIZE 100

int  main(){
        char c;
        int shm_id;
        key_t key;
        char *data, *shm;
        key = 1;
        
        shm_id = shmget(key,SHMSIZE,IPC_CREAT | 0666);

        if(shm_id < 0){
                printf("shmget Error: Fail to create a memory segment\n");
                exit(1);
        }else{
                printf("Memory segment created successfully\n");
                printf("segment id id %d\n", shm_id);
        }
        
        //attach the segement 
        data = shmat(shm_id, NULL, 0);
        
        if (data == (char *) -1){
                printf("shmat Error: Fail to attach\n");
                exit(1);
        }
        
        //put some value in the shared memory
        shm = data;

        //serveris writing to the shared memory
        printf("enter what you want to save in the shared memory.Click ctl + D when finished writing\n");
        printf("Servre writing to the shared memory\n");
        for(; ; ){
                c = getchar();
                if(c == EOF){
                        break;
                }
                *shm++ = c; 
                
        }
        *shm = '\0';
        
        /*the server waits untill the client process has read what was written in the shared memory.
                changes the first character of our memory to '*' */
        printf("Server wating until the client reads data written in the shared memory.\n");
        while(*data != '*')
                sleep(1);
                //cleanup();

                shmdt(data);
                shmctl(shm_id, IPC_RMID, 0);
                exit(0);   
}     
